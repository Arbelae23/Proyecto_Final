#include "level2.h"

Level2::Level2(QWidget *parent) : QWidget(parent) {
    setWindowTitle("Nivel 2");
    resize(600, 400);
}
