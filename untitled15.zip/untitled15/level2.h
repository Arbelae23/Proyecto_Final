#ifndef LEVEL2_H
#define LEVEL2_H

#include <QWidget>
#include <QPushButton>

class Level2 : public QWidget {
    Q_OBJECT

public:
    explicit Level2(QWidget *parent = nullptr);
};

#endif // LEVEL2_H
